<?php
require_once '../condb.php';

// สร้าง SQL เพื่อดึงข้อมูลจากตาราง member
$sql = "SELECT members.member_id, members.first_name, members.last_name, members.email, members.phone, members.join_date
        FROM members"; // ลบเงื่อนไข WHERE หากไม่มีคอลัมน์ role

$stmt = $conn->prepare($sql);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

$index = 1;
?>

<link rel="stylesheet" href="https://cdn.datatables.net/2.1.2/css/dataTables.dataTables.min.css">

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <h1>Members List</h1> <!-- หัวเรื่องของหน้าจอ -->
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="card">
        <div class="card-body">
            <table class="table" id="tb_users">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Join Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $us) : ?>
                        <tr>
                            <td><?php echo $index; ?></td>
                            <td><?php echo $us['first_name']; ?></td>
                            <td><?php echo $us['last_name']; ?></td>
                            <td><?php echo $us['email']; ?></td>
                            <td><?php echo $us['phone']; ?></td>
                            <td><?php echo $us['join_date']; ?></td>
                        </tr>
                        <?php $index++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/2.1.2/js/dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#tb_users').DataTable(); // ใช้ id ที่ถูกต้อง
    });
</script>
