<?php
require_once '../condb.php';

// SQL สำหรับดึงข้อมูลจาก workout_programs
$sql = "SELECT 
    program_id, 
    program_name, 
    duration_weeks, 
    description,
    price  -- เพิ่ม column price
FROM 
    workout_programs";

$stmt = $conn->prepare($sql); 
$stmt->execute(); 
$programs = $stmt->fetchAll(PDO::FETCH_ASSOC); 

$index = 1;
?>

<!-- รวม Bootstrap CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.2/css/dataTables.bootstrap4.min.css">

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <h1>แสดงข้อมูลโปรแกรมการฝึก</h1>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <div class="card">
        <div class="card-body">
            <table class="table table-striped table-bordered" id="tb_users">
                <thead class="thead-dark">
                    <tr>
                        <th>ลำดับ</th>
                        <th>ชื่อโปรแกรม</th>
                        <th>ระยะเวลา (สัปดาห์)</th>
                        <th>คำอธิบาย</th>
                        <th>ราคา</th>  <!-- เพิ่มคอลัมน์ราคา -->
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($programs as $program) : ?>
                        <tr>
                            <td><?php echo $index; ?></td>
                            <td><?php echo htmlspecialchars($program['program_name']); ?></td>
                            <td><?php echo htmlspecialchars($program['duration_weeks']); ?></td>
                            <td><?php echo htmlspecialchars($program['description']); ?></td>
                            <td><?php echo htmlspecialchars(number_format($program['price'], 2)); ?> บาท</td>  <!-- แสดงราคา -->
                        </tr>
                        <?php $index++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>
    <!-- /.card -->
</div>
<!-- /.content-wrapper -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
<script src="https://cdn.datatables.net/2.1.2/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/2.1.2/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#tb_users').DataTable({
            "language": {
                "search": "ค้นหา:",
                "lengthMenu": "แสดง _MENU_ รายการ",
                "info": "แสดง _START_ ถึง _END_ จาก _TOTAL_ รายการ",
                "paginate": {
                    "next": "ถัดไป",
                    "previous": "ก่อนหน้า"
                }
            }
        });
    });
</script>
