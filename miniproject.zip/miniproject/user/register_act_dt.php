<?php
require_once '../condb.php';
// เริ่ม session เพื่อดึงข้อมูลการล็อกอิน
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['user_login'])) { // ถ้าล็อกอินอยู่
    // ดึง user_id ของผู้ใช้ที่ล็อกอิน
    $user_id = $_SESSION['user_login']; 

    // ดึงข้อมูลโปรแกรมฝึกจากตาราง workout_programs
    $sql_programs = "SELECT program_id, program_name, duration_weeks, price FROM workout_programs";
    $stmt_programs = $conn->prepare($sql_programs);
    $stmt_programs->execute();
    $programs = $stmt_programs->fetchAll(PDO::FETCH_ASSOC);

    // ตรวจสอบเมื่อผู้ใช้ส่งฟอร์ม
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // รับค่าจากฟอร์ม
        $program_id = $_POST['program_id'];

        // SQL สำหรับการบันทึกข้อมูลลงในตาราง registers
        $sql_register = "INSERT INTO registers (activity_id, person_id) VALUES(?, ?)";
        $stmt_register = $conn->prepare($sql_register);
        $stmt_register->execute([$program_id, $user_id]);
        // แสดงข้อความยืนยันการลงทะเบียน
        echo "<div class='alert alert-success'>ลงทะเบียนโปรแกรมสำเร็จ!</div>";
    }

    // ดึงข้อมูลการลงทะเบียนของผู้ใช้จากตาราง registers
    $sql_registered = "SELECT r.id, wp.program_name, r.created_at 
                       FROM registers r 
                       JOIN workout_programs wp ON r.activity_id = wp.program_id 
                       WHERE r.person_id = ?";
    $stmt_registered = $conn->prepare($sql_registered);
    $stmt_registered->execute([$user_id]);
    $registrations = $stmt_registered->fetchAll(PDO::FETCH_ASSOC);
}
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>เลือกลงโปรแกรมฝึก</h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card card-outline card-info">
                    <!-- ฟอร์มสำหรับลงทะเบียนโปรแกรมฝึก -->
                    <form action="" method="POST">
                        <div class="card-body">
                            <label for="program_id" class="form-label">เลือกโปรแกรมฝึก</label>
                            <select name="program_id" id="program_id" class="form-control" required>
                                <option value="">-- กรุณาเลือกโปรแกรม --</option>
                                <?php foreach ($programs as $program): ?>
                                <option value="<?php echo $program['program_id']; ?>">
                                    <?php echo $program['program_name'] . " - " . $program['duration_weeks'] . " สัปดาห์ - ราคา " . $program['price'] . " บาท"; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">ลงทะเบียน</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- ตารางแสดงข้อมูลการลงทะเบียนโปรแกรม -->
        <div class="row mt-5">
            <div class="col-md-12">
                <div class="card card-outline card-info">
                    <div class="card-header">
                        <h3 class="card-title">โปรแกรมที่คุณได้ลงทะเบียนไว้</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($registrations)): ?>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>ชื่อโปรแกรม</th>
                                    <th>วันที่ลงทะเบียน</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($registrations as $index => $registration): ?>
                                <tr>
                                    <td><?php echo $index + 1; ?></td>
                                    <td><?php echo htmlspecialchars($registration['program_name']); ?></td>
                                    <td><?php echo htmlspecialchars($registration['created_at']); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php else: ?>
                        <p>ยังไม่มีการลงทะเบียนโปรแกรม</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
